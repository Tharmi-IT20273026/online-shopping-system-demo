import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.chromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
public class PaymentTest {
	private WebDriver driver;
	private PaymentPage PaymentPage;
	
	@BeforeTest
	public void setUp() {
		WebDriverManager.chromedriver().setupp();
		driver = new Chromedriver();
		driver.manager().timeouts().implicitlyWait(10, TimeUnit.SeCONDS);
		driver.get("http://a.testreviewBook.com/Submit");
		driver.findElement(Email),sendKeys(gkahh@gmail.com);
		driver.findElement(Amount),sendKeys(20000/=);
		PaymentPage = new PaymentPage(driver);
	}
	
	@Test
	public void createPaymentTest() {
		Payment Payment= new Payment("gkahh@gmail.com", "20000");
		
	}
	
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}

}
