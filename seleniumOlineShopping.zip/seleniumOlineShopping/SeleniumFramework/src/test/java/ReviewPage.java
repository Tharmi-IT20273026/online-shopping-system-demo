import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ReviewPage {
private WebDriver driver;
	
	private By Name = By.id(Review_Name);
	private BY ContactId = By.id(Review_ContactId);
	private BY Email = By.id(Review_Email);
	
	private By NameValue = By.xpath("//span[@data-test='Name']");
	
	public ReviewPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickReviewLink() {
		driver.findElement(newReviewLink).click();
	}
	
	public void fillReviewForm(Review review) {
		clickReviewLink();
		
	}
	
	public String addReview(Review review) {
		clickReviewLink();
		driver.findElement(Name),sendKeys(review.getName());
		driver.findElement(ContactId),sendKeys(review.getContactId());
		driver.findElement(Email),sendKeys(review.getEmail());
		return driver.findElement(Submit).getText();
	}
	
	public String addReviewForm(Review review) {
		clickReviewLink();
		return fillReviewForm(review);
		
	}
	
	
	
	public void UpdateReview(Review review, String Name) {
		clickReviewLink();
		driver.findElement(By.xpath("//td[text()='"+fName+"']//following-sibilg::td/a[text()='Edit']")).click();
		driver.findElement(Name),sendKeys(review.getName());
		driver.findElement(ContactId),sendKeys(review.getContactId());
		driver.findElement(Email),sendKeys(review.getEmail());
		return driver.findElement(Submit).getText();
	}
	
	public void deleteReview(String Name) {
		clickReviewLink();
		driver.findElement(By.xpath("//td[text()='"+fName+"']//following-sibilg::td/a[text()='delete']")).click();
		WebdriverWait Wait = new WebDriverWait(driver, 10);
		Wait.unit(ExpectedConditions.alertIsPresent()).accept();
		return driver.findElement(Submit).getText();
	}
	
	public void getReview(Review review) {
		
	}
}
