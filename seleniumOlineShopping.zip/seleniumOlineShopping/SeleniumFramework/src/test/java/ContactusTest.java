import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.chromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
public class ContactusTest {
	private WebDriver driver;
	private ContactusPage ContactusPage;
	
	@BeforeTest
	public void setUp() {
		WebDriverManager.chromedriver().setupp();
		driver = new Chromedriver();
		driver.manager().timeouts().implicitlyWait(10, TimeUnit.SeCONDS);
		driver.get("http://a.testreviewBook.com/Submit");
		driver.findElement(By.id(Contactus_Id)).sendKeys(25);
		driver.findElement(By.id(Contactus_Name)).sendKeys(Karini);
		driver.findElement(By.id(Contactus_Address)).sendKeys(Inuvil);
		driver.findElement(By.id(Contactus_Email)).sendKeys(Gkari6@gmail.com);
		driver.findElement(By.id(Contactus_Message)).sendKeys(Hi);
		ContactusPage = new ContactusPage(driver);
	}
	
	@Test
	public void createContactusTest() {
		Contactus Contactus= new Contactus("25","Karini", "Inuvil", "gkari6@gmail.com", "Hi");
		
	}
	
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
