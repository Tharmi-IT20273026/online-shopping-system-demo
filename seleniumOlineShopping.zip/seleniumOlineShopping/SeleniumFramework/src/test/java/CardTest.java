import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.chromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
public class CardTest {
	private WebDriver driver;
	private CardPage CardPage;
	
	@BeforeTest
	public void setUp() {
		WebDriverManager.chromedriver().setupp();
		driver = new Chromedriver();
		driver.manager().timeouts().implicitlyWait(10, TimeUnit.SeCONDS);
		driver.get("http://a.testreviewBook.com/Submit");
		driver.findElement(CardNumber),sendKeys(100);
		driver.findElement(Cardholder),sendKeys(kjas);
		driver.findElement( ExpirationMonth),sendKeys(2);
		driver.findElement(Expiration Year),sendKeys(2022);
		driver.findElement(CVV),sendKeys(25);
		CardPage = new CardPage(driver);
	}
	
	@Test
	public void createCardTest() {
		Card Card= new Card("100", "kjas", "2", "2022", "2");
		
	}
	
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}



