import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PaymentPage {
	private WebDriver driver;

    private BY Email = By.id( Payment_Email);	
	private By Amount = By.id( Payment_Amount);
	 
	private By EmailValue = By.xpath("//span[@data-test='Email']");
	
	public  PaymentPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickPaymentLink() {
		driver.findElement(new PaymentLink).click();
	}
	
	public void fillPaymentForm( Payment  Payment) {
		click PaymentLink();
		
	}
	
	public String addPayment( Payment  Payment) {
		clickPaymentLink();
		driver.findElement(Email),sendKeys( Payment.getEmail());
		driver.findElement(Amount),sendKeys( Payment.getPayment());
		return driver.findElement(Pay).getText();
	}
	
	public String addPaymentForm( Payment  Payment) {
		click PaymentLink();
		return fillPaymentForm( Payment Payment);
	}
	
	public void UpdatePayment( Payment  Payment, String Email) {
		click PaymentLink();
		driver.findElement(By.xpath("//td[text()='"+Email+"']//following-sibilg::td/a[text()='Edit']")).click();
		driver.findElement(Email),sendKeys( Payment.getEmail());
		driver.findElement(Amount),sendKeys( Payment.getAmount());
		return driver.findElement(Pay).getText();
	}
	
	public void deletePayment(String Email) {
		clickPaymentLink();
		driver.findElement(By.xpath("//td[text()='"+Email+"']//following-sibilg::td/a[text()='delete']")).click();
		WebdriverWait Wait = new WebDriverWait(driver, 10);
		Wait.unit(ExpectedConditions.alertIsPresent()).accept();
		return driver.findElement(Pay).getText();
	}
	
	public void getPayment( Payment  Payment) {
		
	}
}
