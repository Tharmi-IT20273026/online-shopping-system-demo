import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class RegistrationPage {

	private WebDriver driver;

    private BY User_Name = By.id(Registration_User_Name);	
	private By New_password = By.id(Registration_New_password);
	  private BY Confirm_password = By.id(Registration_ Confirm_password);
	
	
	private By FullNameValue = By.xpath("//span[@data-test='FullName']");
	
	public RegistrationPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickRegistrationLink() {
		driver.findElement(newRegistrationLink).click();
	}
	
	public void fillRegistrationForm(Registration Registration) {
		clickRegistrationLink();
		
	}
	
	public String addRegistration(Registration Registration) {
		clickRegistrationLink();
		driver.findElement( User_Name),sendKeys(Registration.get User_Name());
		driver.findElement(New_password),sendKeys(Registration.getNew_password());
		driver.findElement(Confirm_password),sendKeys(Registration.getConfirm_password());
		return driver.findElement(Register).getText();
	}
	
	public String addRegistrationForm(Registration Registration) {
		clickRegistrationLink();
		return fillRegistrationForm(Registration Registration);
		
	}
	
	
	
	public void UpdateRegistration(Registration Registration, String UserName) {
		clickRegistrationLink();
		driver.findElement(By.xpath("//td[text()='"+UName+"']//following-sibilg::td/a[text()='Edit']")).click();
		driver.findElement(User_Name),sendKeys(Registration.getUser_Name());
		driver.findElement(New_password),sendKeys(Registration.getNew_password());
		driver.findElement(Confirm_password),sendKeys(Registration.getConfirm_password());
		return driver.findElement(Register).getText();
	}
	
	public void deleteRegistration(String UserName) {
		clickRegistrationLink();
		driver.findElement(By.xpath("//td[text()='"+UName+"']//following-sibilg::td/a[text()='delete']")).click();
		WebdriverWait Wait = new WebDriverWait(driver, 10);
		Wait.unit(ExpectedConditions.alertIsPresent()).accept();
		return driver.findElement(Register).getText();
	}
	
	public void getRegistration(Registration Registration) {
		
	}
}
