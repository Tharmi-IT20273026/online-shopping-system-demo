import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.chromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
public class RegistrationTest {
	private WebDriver driver;
	private RegistrationPage RegistrationPage;
	
	@BeforeTest
	public void setUp() {
		WebDriverManager.chromedriver().setupp();
		driver = new Chromedriver();
		driver.manager().timeouts().implicitlyWait(10, TimeUnit.SeCONDS);
		driver.get("http://a.testreviewBook.com/Submit");
		driver.findElement(User_Name),sendKeys(Kamal);
		driver.findElement(New_password),sendKeys(225);
		driver.findElement(Confirm_password),sendKeys(225);
		RegistrationPage = new RegistrationPage(driver);
	}
	
	@Test
	public void createRegistrationTest() {
		Payment Registration= new Registration("kamal", "225", "225");
		
	}
	
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
