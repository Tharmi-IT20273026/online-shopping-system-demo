import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CardPage {
	private WebDriver driver;

    private BY CardNumber = By.id(Card_CardNumber);	
	private By Cardholder = By.id(Card_Cardholder);
	  private BY  Expiration month = By.id(Card_ Expiration month);
	private BY Expiration Year = By.id(Card_Expiration Year);
	  private BY CVV = By.id(Card_CVV);
	
	private By FullNameValue = By.xpath("//span[@data-test='FullName']");
	
	public CardPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickCardLink() {
		driver.findElement(newCardLink).click();
	}
	
	public void fillCardForm(Card Card) {
		clickCardLink();
		
	}
	
	public String addCard(Card Card) {
		clickCardLink();
		driver.findElement(CardNumber),sendKeys(Card.getCardNumber());
		driver.findElement(Cardholder),sendKeys(Card.getCardholder());
		driver.findElement( ExpirationMonth),sendKeys(Card.get ExpirationMonth());
		driver.findElement(Expiration Year),sendKeys(Card.getExpiration Year());
		driver.findElement(CVV),sendKeys(Card.getCVV());
		return driver.findElement(ADD).getText();
	}
	
	public String addCardForm(Card Card) {
		clickCardLink();
		return fillCardForm(Card Card);
		
	}
	
	
	
	public void UpdateCard(Card Card, String CardNumber) {
		clickCardLink();
		driver.findElement(By.xpath("//td[text()='"+CNumber+"']//following-sibilg::td/a[text()='Edit']")).click();
		driver.findElement(CardNumber),sendKeys(Card.getCardNumber());
		driver.findElement(Cardholder),sendKeys(Card.getCardholder());
		driver.findElement( ExpirationMonth),sendKeys(Card.get ExpirationMonth());
		driver.findElement(Expiration Year),sendKeys(Card.getExpiration Year());
		driver.findElement(CVV),sendKeys(Card.getCVV());
		return driver.findElement(Pay).getText();
	}
	
	public void deleteCard(String CardNumber) {
		clickCardLink();
		driver.findElement(By.xpath("//td[text()='"+CNumber+"']//following-sibilg::td/a[text()='delete']")).click();
		WebdriverWait Wait = new WebDriverWait(driver, 10);
		Wait.unit(ExpectedConditions.alertIsPresent()).accept();
		return driver.findElement(Pay).getText();
	}
	
	public void getCard(Card Card) {
		
	}
}
