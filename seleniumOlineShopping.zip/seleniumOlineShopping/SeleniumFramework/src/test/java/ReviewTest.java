
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.chromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ReviewTest {
	
	private WebDriver driver;
	private ReviewPage reviewPage;
	
	@BeforeTest
	public void setUp() {
		WebDriverManager.chromedriver().setupp();
		driver = new Chromedriver();
		driver.manager().timeouts().implicitlyWait(10, TimeUnit.SeCONDS);
		driver.get("http://a.testreviewBook.com/Submit");
		driver.findElement(By.id(Review_Name)).sendKeys(Karini);
		driver.findElement(By.id(Review_ContactId)).sendKeys(25);
		driver.findElement(By.id(Review_Email)).sendKeys(Gkari6@gmail.com);
        reviewPage = new ReviewPage(driver);
	}
	
	@Test
	public void createReviewTest() {
		Review review = new Review("Karini", "25", "gkari6@gmail.com");
		
	}
	
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
