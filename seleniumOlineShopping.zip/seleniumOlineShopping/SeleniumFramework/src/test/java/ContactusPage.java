import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ContactusPage {
private WebDriver driver;

    private BY Id = By.id(Contactus_Id);	
	private By FullName = By.id(Contactus_FullName);
	  private BY Address = By.id(Contactus_Address);
	private BY Email = By.id(Contactus_Email);
	  private BY Message = By.id(Contactus_Message);
	
	private By FullNameValue = By.xpath("//span[@data-test='FullName']");
	
	public ContactusPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clickContactusLink() {
		driver.findElement(newContactusLink).click();
	}
	
	public void fillContactusForm(Contactus contactus) {
		clickContactusLink();
		
	}
	
	public String addContactus(Contactus contactus) {
		clickContactusLink();
		driver.findElement(Id),sendKeys(contactus.getId());
		driver.findElement(FullName),sendKeys(contactus.getFullName());
		driver.findElement(Address),sendKeys(contactus.getAddress());
		driver.findElement(Email),sendKeys(review.getEmail());
		driver.findElement(Message),sendKeys(contactus.getMessage());
		return driver.findElement(Submit).getText();
	}
	
	public String addContactusForm(Contactus contactus) {
		clickContactusLink();
		return fillContactusForm(contactus);
		
	}
	
	
	
	public void UpdateContactus(Contactus contactus, String FullName) {
		clickContactusLink();
		driver.findElement(By.xpath("//td[text()='"+fName+"']//following-sibilg::td/a[text()='Edit']")).click();
		driver.findElement(Id),sendKeys(contactus.getId());
		driver.findElement(FullName),sendKeys(contactus.getFullName());
		driver.findElement(Address),sendKeys(contactus.getAddress());
		driver.findElement(Email),sendKeys(Contactus.getEmail());
		driver.findElement(Message),sendKeys(contactus.getMessaage());
		return driver.findElement(Submit).getText();
	}
	
	public void deleteContactus(String FullName) {
		clickContactusLink();
		driver.findElement(By.xpath("//td[text()='"+fName+"']//following-sibilg::td/a[text()='delete']")).click();
		WebdriverWait Wait = new WebDriverWait(driver, 10);
		Wait.unit(ExpectedConditions.alertIsPresent()).accept();
		return driver.findElement(Submit).getText();
	}
	
	public void getContactus(Contactus contactus) {
		
	}
}
