import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.chromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
public class Card {
	private String CardNumber;
	private String Cardholder;
	private String Expirationmonth;
	private String ExpirationYear;
	private String CVV;
	public void Card(String CardNumber , String Caedholder, String ExpirationMonth ,String Expirationyear, String CVV) {
		this.CardNumber = CardNumber;
		this.Cardholder = Cardholder;
		this.ExpirationMonth = ExpirationMonth;
		this.ExpirationYear = ExpirationYear;
		this.CVV = CVV;
	}
	public String getCardNumber() {
		return CardNumber;
	}
	public void setCardNumber(String cardNumber) {
		CardNumber = cardNumber;
	}
	public String getCardholder() {
		return Cardholder;
	}
	public void setCardholder(String cardholder) {
		Cardholder = cardholder;
	}
	public String getExpiration() {
		return Expiration;
	}
	public void setExpiration(String expiration) {
		Expiration = expiration;
	}
	public String getExpiration() {
		return Expiration;
	}
	public void setExpiration(String expiration) {
		Expiration = expiration;
	}
	public String getCVV() {
		return CVV;
	}
	public void setCVV(String cVV) {
		CVV = cVV;
	}
	
}
