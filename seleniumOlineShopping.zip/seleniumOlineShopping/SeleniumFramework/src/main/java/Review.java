
public class Review {
	private String Name;
	private String ContactId;
	private String Email;
	public Review(String Name, String ContactId, String Email) {
		this.Name = Name;
		this.ContactId = ContactId;
		this.Email = Email;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getContactId() {
		return ContactId;
	}
	public void setContactId(String contactId) {
		ContactId = contactId;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
}
