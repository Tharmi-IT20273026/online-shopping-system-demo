import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.chromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
public class Registration {
	private String User_Email;
	private String New_password;
	private String Confirm_password;
	public void Registration(String User_Email, String New_password, String Confirm_password  ) {
		this.User_Email = User_Email;
		this. New_password =  New_password;
		this.Confirm_password=Confirm_password;
	}
	public String getUser_Email() {
		return User_Email;
	}
	public void setUser_Email(String user_Email) {
		User_Email = user_Email;
	}
	public String getNew_password() {
		return New_password;
	}
	public void setNew_password(String new_password) {
		New_password = new_password;
	}
	public String getConfirm_password() {
		return Confirm_password;
	}
	public void setConfirm_password(String confirm_password) {
		Confirm_password = confirm_password;
	}
	
	

}
