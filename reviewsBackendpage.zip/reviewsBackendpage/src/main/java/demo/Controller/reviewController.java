package demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import demo.model.review;
import demo.Service.reviewService;

@RestController
@RequestMapping("/reviews")
public class reviewController {
    @Autowired
    reviewService  reviewService;

    @PostMapping("/review")
    public void add(@RequestBody review review) {
        reviewService.adddetails(review);
    }


}


