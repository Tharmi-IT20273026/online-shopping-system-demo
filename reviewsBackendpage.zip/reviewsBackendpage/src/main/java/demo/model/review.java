package demo.model;

import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "review")
@Table(name = "review")
public class review{
    @Column(name = "review")
    private String review;
    @Column(name = "NAME")
    private String name;
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "CONTACTID")
    private int contactid;
    @Column(name = "EMAIL")
    private String email;
    @Id
    private Long id;

    public String getReview() {
        return review;
    }

    public String getName() {
        return name;
    }

    public int getContactid() {
        return contactid;
    }

    public String getEmail() {
        return email;
    }

    public void setReview(String Review) {
        this.review = review;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setContactId(int contactid) {
        this.contactid = contactid;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}

