package com.example.reviewsbackendpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewsBackendpageApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReviewsBackendpageApplication.class, args);
    }

}
