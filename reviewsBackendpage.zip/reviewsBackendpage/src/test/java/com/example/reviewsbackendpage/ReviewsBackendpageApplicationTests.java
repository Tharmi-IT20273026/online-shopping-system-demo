package com.example.reviewsbackendpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewsBackendpageApplicationTests {

    @Test
    void contextLoads() {
    }

}
