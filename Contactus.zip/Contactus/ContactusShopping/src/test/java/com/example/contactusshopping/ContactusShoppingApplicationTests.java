package com.example.contactusshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactusShoppingApplicationTests {

    @Test
    void contextLoads() {
    }

}
