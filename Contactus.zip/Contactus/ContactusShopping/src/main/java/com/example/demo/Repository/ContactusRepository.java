package com.example.demo.Repository;

import com.example.demo.model.Contactus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactusRepository extends JpaRepository <Contactus,Integer>{
}
