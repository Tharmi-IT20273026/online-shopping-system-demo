package com.example.contactusshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactusShoppingApplication {

    public static void main(String[] args) {
        SpringApplication.run(ContactusShoppingApplication.class, args);
    }

}
