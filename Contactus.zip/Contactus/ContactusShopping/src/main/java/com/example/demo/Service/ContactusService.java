package com.example.demo.Service;

import com.example.demo.model.Contactus;
import com.example.demo.Repository.ContactusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
@Service
@Transactional
public class ContactusService {
    @Autowired
    private ContactusRepository ContactusRepository;
    public List<Contactus> listAllContactus() {
        return ContactusRepository.findAll();
    }

    public void submitContactus(Contactus Contactus) {
        ContactusRepository.save(Contactus);
    }

    public Contactus getContactus(Integer id) {
        return ContactusRepository.findById(id).get();
    }

    public void deleteContactus(Integer id) {
        ContactusRepository.deleteById(id);
    }
}
