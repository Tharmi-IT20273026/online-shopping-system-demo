package com.example.demo.Controller;

import com.example.demo.model.Contactus;
import com.example.demo.Service.ContactusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/Contactus")
public class ContactusController {
    @Autowired
    ContactusService  ContactusService;

    @GetMapping("")
    public List< Contactus> list() {
        return  ContactusService.listAllContactus();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Contactus> get(@PathVariable Integer id) {
        try {
            Contactus Contactus = ContactusService.getContactus(id);
            return new ResponseEntity<Contactus>(Contactus, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<Contactus>(HttpStatus.NOT_FOUND);
        }
    }
    @PostMapping("/")
    public void add(@RequestBody Contactus Contactus) {
        ContactusService.submitContactus(Contactus);
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@RequestBody Contactus Contactus, @PathVariable Integer id) {
        try {
            Contactus existUser = ContactusService.getContactus(id);
            Contactus.getId();
            ContactusService.submitContactus(Contactus);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
