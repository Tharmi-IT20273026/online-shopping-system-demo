package com.example.OnlineShoppingSystem.models;

import javax.persistence.*;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank; 


@Entity(name = "seller")
@Table(name = "seller")

public class Seller {
	@NotBlank (message = "Name is mandatory")
	@Column(name = "NAME")
    private String name;
	
	@NotBlank (message = "type is mandatory")
    @Column(name = "TYPE")
    private String type;
	
	@NotBlank (message = "price is mandatory")
	@DecimalMin("1.00")
    @Column(name = "PRICE")
    private int price;
	
	@NotBlank (message = "size is mandatory")
    @Column(name = "SIZE")
    private String size;
	
	
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private int id;
    
	@NotBlank (message = "colour is mandatory")
    @Column(name = "COLOR")
    private String color;

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getPrice() {
        return price;
    }

    @Id
    public int getId() {
        return id;
    }

    public String getSize() {
        return size;
    }

    public String getColor() {
        return color;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSize(String size) {
        this.size = size;
    }
}



