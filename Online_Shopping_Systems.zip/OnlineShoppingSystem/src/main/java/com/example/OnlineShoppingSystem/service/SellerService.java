package com.example.OnlineShoppingSystem.service;



import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.OnlineShoppingSystem.models.Seller;
import com.example.OnlineShoppingSystem.repository.SellerRepository;

@Service
@Transactional
public class SellerService {

	 @Autowired
	    private SellerRepository sellerRepository;
	 
	 public void addStocks(Seller seller) {
	        sellerRepository.save(seller);
	    }
	    
	 public List<Seller>listAllStocks() {
	        return sellerRepository.findAll();
	    }
	 public void deleteStocks(Integer id) {
	        sellerRepository.deleteById(id);
	    }
	 public Seller getStock(Integer id) {
	        return sellerRepository.findById(id).get();
	    }


		
	
}
