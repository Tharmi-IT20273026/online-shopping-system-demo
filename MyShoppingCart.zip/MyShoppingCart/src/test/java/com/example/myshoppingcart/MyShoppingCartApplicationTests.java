package com.example.myshoppingcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyShoppingCartApplicationTests {

    @Test
    void contextLoads() {
    }

}
