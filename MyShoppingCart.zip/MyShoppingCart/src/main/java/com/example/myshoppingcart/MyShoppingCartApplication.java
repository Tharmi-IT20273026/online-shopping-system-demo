package com.example.myshoppingcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyShoppingCartApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyShoppingCartApplication.class, args);
    }

}
