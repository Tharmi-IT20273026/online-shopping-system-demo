package com.example.OnlineShoppingSystem.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.OnlineShoppingSystem.models.Seller;
import com.example.OnlineShoppingSystem.repository.SellerRepository;

@Service
@Transactional
public class SellerService {

	 @Autowired
	    private SellerRepository sellerRepository;
	 
	 public void addStocks(Seller seller) {
	        sellerRepository.save(seller);
	    }
	    
}
