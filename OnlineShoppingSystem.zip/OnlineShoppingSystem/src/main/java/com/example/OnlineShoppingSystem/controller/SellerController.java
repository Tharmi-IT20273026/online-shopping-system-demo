package com.example.OnlineShoppingSystem.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineShoppingSystem.models.Seller;
import com.example.OnlineShoppingSystem.service.SellerService;

@RestController
//@RequestMapping("/seller")
public class SellerController {
	
	 @Autowired
	    SellerService sellerService;
	 
	 @PostMapping("/seller")
	    public void add(@RequestBody Seller seller) {
	         sellerService.addStocks(seller);
	    }
	    

}

/**LoginController{
 * LoginService wired
 * @PostMapping("/login")
 * public LoginResponseDTO validate(UserLogin){
 * loginservice.validatUser(userLogin)
*
}

*/