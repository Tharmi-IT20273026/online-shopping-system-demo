package demo.Repository;

import demo.model.review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface reviewRepository extends JpaRepository <review,Integer>{

}
