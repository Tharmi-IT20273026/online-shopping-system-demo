package demo.Repository;

import demo.model.contactus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface contactusRepository extends JpaRepository <contactus,Integer>{


}
